//
//  DetailMarineViewController.swift
//  HospitalMap
//
//  Created by KPUGAME on 02/06/2019.
//  Copyright © 2019 Sumin Yeom. All rights reserved.
//

import UIKit

class DetailMarineViewController: UIViewController, XMLParserDelegate
{
    @IBOutlet weak var marineName: UILabel!
    @IBOutlet weak var marineImage: UIImageView!
    @IBOutlet weak var marineSection: UILabel!
    @IBOutlet weak var marineHabitat: UILabel!
    @IBOutlet weak var marineExplain: UITextView!
    
    var url : String?
    var mapurl : String?
    
    var parser = XMLParser()
    var parser2 = XMLParser()
    
    let postsname : [String] = ["이름", "사진", "설명", "과", "서식지", "XPos", "YPos"]
    
    var posts : [String] = ["", "", "", "", "", "", ""]
    
    var element = NSString()
    
    var sciKr = NSMutableString()
    var fileNm = NSMutableString()
    var chrtr = NSMutableString()
    var phylgntClas = NSMutableString()
    var distrInh = NSMutableString()
    
    var XPos = NSMutableString()
    var YPos = NSMutableString()
    
    func beginParsing()
    {
        print("url is \(url!)")
        posts = []
        parser = XMLParser(contentsOf:(URL(string:url!))!)!
        parser.delegate = self
        parser.parse()
        //parser2 = XMLParser(contentsOf:(URL(string:mapurl!))!)!
        //parser2.delegate = self
        //parser2.parse()
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        
        if (elementName as NSString).isEqual("item")
        {
            posts = ["", "", "", "", "", "", ""]
            
            sciKr = NSMutableString()
            sciKr = ""
            fileNm = NSMutableString()
            fileNm = ""
            
            chrtr = NSMutableString()
            chrtr = ""
            
            phylgntClas = NSMutableString()
            phylgntClas = ""
            distrInh = NSMutableString()
            distrInh = ""
            
            XPos = NSMutableString()
            XPos = ""
            YPos = NSMutableString()
            YPos = ""
        }
    }
    
    func parser(_ parser:XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "sciKr")
        {
            sciKr.append(string)
        }
        else if element.isEqual(to: "fileNm")
        {
            fileNm.append(string)
        }
        else if element.isEqual(to: "chrtr")
        {
            chrtr.append(string)
        }
        else if element.isEqual(to: "phylgntClas")
        {
            phylgntClas.append(string)
        }
        else if element.isEqual(to: "distrInh")
        {
            distrInh.append(string)
        }
        else if element.isEqual(to: "lonD")
        {
            XPos.append(string)
        }
        else if element.isEqual(to: "latD")
        {
            YPos.append(string)
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "item")
        {
            if !sciKr.isEqual(nil)
            {
                posts[0] = sciKr as String
            }
            
            if !fileNm.isEqual(nil)
            {
                posts[1] = fileNm as String
            }
            
            if !chrtr.isEqual(nil)
            {
                posts[2] = chrtr as String
            }
            
            if !phylgntClas.isEqual(nil)
            {
                posts[3] = phylgntClas as String
            }
            
            if !distrInh.isEqual(nil)
            {
                posts[4] = distrInh as String
            }
            
            if (!XPos.isEqual(nil))
            {
                posts[5] = XPos as String
            }
            
            if (!YPos.isEqual(nil))
            {
                posts[6] = YPos as String
            }
        }
    }
    
    func InputInformation() {
        marineName.text = sciKr as String
        marineImage.image = UIImage(data: try! Data(contentsOf: URL(string:fileNm as String)!))
        
        marineSection.text = phylgntClas as String
        marineHabitat.text = distrInh as String
        marineExplain.text = chrtr as String
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        beginParsing()
        InputInformation()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if XPos != ""
        {
            if segue.identifier == "segueToMapView"
            {
                if let mapViewController = segue.destination as? MapViewController
                {
                    mapViewController.posts = posts
                }
            }
        }
        else{
            //fatalError("지도 정보가 없습니다")
        }
    }
    
    /*
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HospitalCell", for: indexPath)
        
        cell.textLabel?.text = postsname[indexPath.row]
        cell.detailTextLabel?.text = posts[indexPath.row]
        cell.imageView?.image = UIImage(data: try! Data(contentsOf: URL(string:fileNm as String)!))
        
        /*
         if let url = URL(string: ((posts.object(at: indexPath.row) as AnyObject).value(forKey: "fileNm") as! NSString as String))
         {
         if let data = try? Data(contentsOf: url)
         {
         cell.imageView?.image = UIImage(data: data)
         }
         }
         */
        
        return cell
    }*/
    
}
