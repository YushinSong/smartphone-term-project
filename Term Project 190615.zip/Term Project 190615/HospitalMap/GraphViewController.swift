//
//  ViewController.swift
//  HospitalMap
//
//  Created by kpugame on 2019. 4. 22..
//  Copyright © 2019년 Sumin Yeom. All rights reserved.
//

import UIKit
import Speech

class GraphViewController: UIViewController
{
    @IBOutlet weak var counterView: CounterView!
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var graphView: GraphView!
    
    var isGraphViewShowing = false
    
    var audioController : AudioController!
    @IBAction func counterViewTap(_ gesture: UITapGestureRecognizer?)
    {
        audioController = AudioController()
        audioController.preloadAudioEffects(audioFilesNames: AudioEffectFiles)
        audioController.playerEffect(name: Blop)
        if(isGraphViewShowing)
        {
            UIView.transition(from: graphView, to: counterView, duration: 1.0, options: [.transitionFlipFromLeft, .showHideTransitionViews], completion: nil)
        }
        else
        {
            UIView.transition(from: counterView, to: graphView, duration: 1.0, options: [.transitionFlipFromRight, .showHideTransitionViews], completion: nil)
        }
        
        isGraphViewShowing = !isGraphViewShowing
    }
    
    func startParticle()
    {
        let startX: CGFloat = 0
        let endX: CGFloat = ScreenWidth + 300
        let startY: CGFloat = 200
        
        let stars = ExplodeView(frame: CGRect(x: startX, y: startY, width: 10, height: 10))
        self.view.addSubview(stars)
        self.view.sendSubviewToBack(stars)
        UIView.animate(withDuration: 3.0,
                       delay: 0.0,
                       options: UIView.AnimationOptions.curveEaseOut,
                       animations: {stars.center = CGPoint(x: endX, y: startY)},
                       completion: {(value:Bool) in stars.removeFromSuperview()
        })
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        startParticle()
    }

}

