import UIKit

class DetailHospitalTableViewController: UITableViewController, XMLParserDelegate
{
    @IBOutlet var detailTableView: UITableView!
    
    var url : String?
    
    var parser = XMLParser()
    
    let postsname : [String] = ["이름", "사진", "설명", "과", "서식지"]
    
    var posts : [String] = ["", "", "", "", ""]
    
    var element = NSString()
    
    var sciKr = NSMutableString()
    var fileNm = NSMutableString()
    var chrtr = NSMutableString()
    var phylgntClas = NSMutableString()
    var distrInh = NSMutableString()
    
    func beginParsing()
    {
        print("\(url)")
        posts = []
        parser = XMLParser(contentsOf:(URL(string:url!))!)!
        parser.delegate = self
        parser.parse()
        detailTableView!.reloadData()
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        
        if (elementName as NSString).isEqual("item")
        {
            posts = ["", "", "", "", ""]
            
            sciKr = NSMutableString()
            sciKr = ""
            fileNm = NSMutableString()
            fileNm = ""
            
            chrtr = NSMutableString()
            chrtr = ""
            
            phylgntClas = NSMutableString()
            phylgntClas = ""
            distrInh = NSMutableString()
            distrInh = ""
        }
    }
    
    func parser(_ parser:XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "sciKr")
        {
            sciKr.append(string)
        }
        else if element.isEqual(to: "fileNm")
        {
            fileNm.append(string)
        }
        else if element.isEqual(to: "chrtr")
        {
            chrtr.append(string)
        }
        else if element.isEqual(to: "phylgntClas")
        {
            phylgntClas.append(string)
        }
        else if element.isEqual(to: "distrInh")
        {
            distrInh.append(string)
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "item")
        {
            if !sciKr.isEqual(nil)
            {
                posts[0] = sciKr as String
            }
            
            if !fileNm.isEqual(nil)
            {
                posts[1] = fileNm as String
            }
            
            if !chrtr.isEqual(nil)
            {
                posts[2] = chrtr as String
            }
            
            if !phylgntClas.isEqual(nil)
            {
                posts[3] = phylgntClas as String
            }
            
            if !distrInh.isEqual(nil)
            {
                posts[4] = distrInh as String
            }
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        beginParsing()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HospitalCell", for: indexPath)
        
        cell.textLabel?.text = postsname[indexPath.row]
        cell.detailTextLabel?.text = posts[indexPath.row]
        cell.imageView?.image = UIImage(data: try! Data(contentsOf: URL(string:fileNm as String)!))
        
        /*
        if let url = URL(string: ((posts.object(at: indexPath.row) as AnyObject).value(forKey: "fileNm") as! NSString as String))
        {
            if let data = try? Data(contentsOf: url)
            {
                cell.imageView?.image = UIImage(data: data)
            }
        }
        */
        
        return cell
    }
    
}
