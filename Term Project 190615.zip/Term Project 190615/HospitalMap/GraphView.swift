//
//  GraphView.swift
//  HospitalMap
//
//  Created by kpugame on 2019. 6. 15..
//  Copyright © 2019년 Sumin Yeom. All rights reserved.
//

import UIKit

class GraphView: UIView
{
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
