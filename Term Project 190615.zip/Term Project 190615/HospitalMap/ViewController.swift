//
//  ViewController.swift
//  HospitalMap
//
//  Created by kpugame on 2019. 4. 22..
//  Copyright © 2019년 Sumin Yeom. All rights reserved.
//

import UIKit
import Speech

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    @IBOutlet weak var pickerView: UIPickerView!
    
    @IBOutlet weak var transcribeButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var myTextView: UITextView!
    
    //private let speechRecognizer = SFSpeechRecognizer()!
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "ko-KR"))!
    
    private var speechRecognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var speechRecognitionTask: SFSpeechRecognitionTask?
    
    private let audioEngine = AVAudioEngine()
    
    @IBAction func startTranscribing(_ sender: Any)
    {
        transcribeButton.isEnabled = false
        stopButton.isEnabled = true
        try! startSession()
    }
    
    func startSession() throws
    {
        if let recognitionTask = speechRecognitionTask
        {
            recognitionTask.cancel()
            self.speechRecognitionTask = nil
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(AVAudioSession.Category.playAndRecord,
                                     mode: AVAudioSession.Mode.default,
                                     options: AVAudioSession.CategoryOptions.defaultToSpeaker)
        
        speechRecognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        guard let recognitionRequest = speechRecognitionRequest else
        { fatalError("SFSpeechAudioBufferRecognitionRequest object creation failed") }
        
        let inputNode = audioEngine.inputNode
        recognitionRequest.shouldReportPartialResults = true
        
        speechRecognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest) { result, error in
            
            var finished = false
            
            if let result = result
            {
                self.myTextView.text = result.bestTranscription.formattedString
                finished = result.isFinal
            }
            
            if error != nil || finished
            {
                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)
                
                self.speechRecognitionRequest = nil
                self.speechRecognitionTask = nil
                
                self.transcribeButton.isEnabled = true
            }
        }
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer: AVAudioPCMBuffer, when: AVAudioTime) in self.speechRecognitionRequest?.append(buffer) }
        
        audioEngine.prepare()
        try audioEngine.start()
    }
    
    @IBAction func stopTranscribing(_ sender: Any)
    {
        if audioEngine.isRunning
        {
            audioEngine.stop()
            speechRecognitionRequest?.endAudio()
            transcribeButton.isEnabled = true
            stopButton.isEnabled = false
        }
        
        switch (self.myTextView.text)
        {
        case "바닷가" : self.pickerView.selectRow(0, inComponent: 0, animated: true)
            searchKey = "%EB%B0%94%EB%8B%B7%EA%B0%80"
            break
        case "갯벌" : self.pickerView.selectRow(1, inComponent: 0, animated: true)
            searchKey = "%EA%B0%AF%EB%B2%8C"
            break
        case "모래" : self.pickerView.selectRow(2, inComponent: 0, animated: true)
            searchKey = "%EB%AA%A8%EB%9E%98"
            break
        case "바위" : self.pickerView.selectRow(3, inComponent: 0, animated: true)
            searchKey = "%EB%B0%94%EC%9C%84"
            break
        case "강" : self.pickerView.selectRow(4, inComponent: 0, animated: true)
            searchKey = "%EA%B0%95"
            break
        case "저수지" : self.pickerView.selectRow(5, inComponent: 0, animated: true)
            searchKey = "%EC%A0%80%EC%88%98%EC%A7%80"
            break
        case "호수" : self.pickerView.selectRow(6, inComponent: 0, animated: true)
            searchKey = "%ED%98%B8%EC%88%98"
            break
        case "순천만" : self.pickerView.selectRow(7, inComponent: 0, animated: true)
            searchKey = "%EC%88%9C%EC%B2%9C%EB%A7%8C"
            break
        case "산과 들" : self.pickerView.selectRow(8, inComponent: 0, animated: true)
            searchKey = "%EC%82%B0%EA%B3%BC%20%EB%93%A4"
            break
        case "농경지" : self.pickerView.selectRow(9, inComponent: 0, animated: true)
            searchKey = "%EB%86%8D%EA%B2%BD%EC%A7%80"
            break
        case "염전" : self.pickerView.selectRow(10, inComponent: 0, animated: true)
            searchKey = "%EC%97%BC%EC%A0%84"
            break
        case "하천" : self.pickerView.selectRow(11, inComponent: 0, animated: true)
            searchKey = "%ED%95%98%EC%B2%9C"
            break
        case "암반" : self.pickerView.selectRow(12, inComponent: 0, animated: true)
            searchKey = "%EC%95%94%EB%B0%98"
            break
        case "조하대" : self.pickerView.selectRow(13, inComponent: 0, animated: true)
            searchKey = "%EC%A1%B0%ED%95%98%EB%8C%80"
            break
        case "둑" : self.pickerView.selectRow(14, inComponent: 0, animated: true)
            searchKey = "%EB%91%91"
            break
        case "습지" : self.pickerView.selectRow(15, inComponent: 0, animated: true)
            searchKey = "%EC%8A%B5%EC%A7%80"
            break
        case "연안" : self.pickerView.selectRow(16, inComponent: 0, animated: true)
            searchKey = "%EC%97%B0%EC%95%88"
            break
        case "숲" : self.pickerView.selectRow(17, inComponent: 0, animated: true)
            searchKey = "%EC%88%B2"
            break
        default: break
        }
    }
    
    func authorizeSR()
    {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            OperationQueue.main.addOperation {
                switch authStatus
                {
                case .authorized:
                    self.transcribeButton.isEnabled = true
                    
                case .denied:
                    self.transcribeButton.isEnabled = false
                    self.transcribeButton.setTitle("Speech recognition access denied by user",for: .disabled)
                    
                case .restricted:
                    self.transcribeButton.isEnabled = false
                    self.transcribeButton.setTitle("Speech recognition restricted on device",for: .disabled)
                    
                case .notDetermined:
                    self.transcribeButton.isEnabled = false
                    self.transcribeButton.setTitle("Speech recognition not authorized",for: .disabled)
                }
            }
        }
    }
    
    @IBAction func doneToPickerViewController(segue:UIStoryboardSegue)
    {
        
    }
    
    var pickerDataSource = ["바닷가", "갯벌", "모래", "바위", "강", "저수지", "호수", "순천만", "산과 들",
                            "농경지", "염전", "하천", "암반", "조하대", "둑", "습지", "연안", "숲"]
    
    //위도 경도 나오는 링크 : http://apis.data.go.kr/B551979/marineOrganismInhabitInfoService/getHabitatGisList?type=1&pageNo=1&numOfRows=300&_type=xml&searchKey=%EB%B0%94%EB%8B%B7%EA%B0%80&ServiceKey=1sIk903elzkNJeOdkVsUMH%2FoYyHI%2BKa2y%2Ft6%2BdVox%2BFK2CGia3TP3PlSZLiEBX9zJlDEeam5n27dgKX2JbusHg%3D%3D
    //getPhotographDescriptionHabitatList
    
    
    var url : String = "http://apis.data.go.kr/B551979/marineOrganismInhabitInfoService/getPhotographDescriptionHabitatList?type=1&numOfRows=300&_type=xml&searchKey="
    var url2 : String = "&ServiceKey=1sIk903elzkNJeOdkVsUMH%2FoYyHI%2BKa2y%2Ft6%2BdVox%2BFK2CGia3TP3PlSZLiEBX9zJlDEeam5n27dgKX2JbusHg%3D%3D"
    
    var searchKey : String = "%EB%B0%94%EB%8B%B7%EA%B0%80" //디폴트 시구코드 = 광진구
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1 //pickerView가 1개니까 휠 1개
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickerDataSource.count //배열의 갯수
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return pickerDataSource[row] //배열의 데이터
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        if row == 0
        {
            searchKey = "%EB%B0%94%EB%8B%B7%EA%B0%80" //광진구
        }
        else if row == 1
        {
            searchKey = "%EA%B0%AF%EB%B2%8C" //구로구
        }
        else if row == 2
        {
            searchKey = "%EB%AA%A8%EB%9E%98" //동대문구
        }
        else if row == 3
        {
            searchKey = "%EB%B0%94%EC%9C%84" //종로구
        }
        else if row == 4
        {
            searchKey = "%EA%B0%95" //종로구
        }
        else if row == 5
        {
            searchKey = "%EC%A0%80%EC%88%98%EC%A7%80" //종로구
        }
        else if row == 6
        {
            searchKey = "%ED%98%B8%EC%88%98" //종로구
        }
        else if row == 7
        {
            searchKey = "%EC%88%9C%EC%B2%9C%EB%A7%8C" //종로구
        }
        else if row == 8
        {
            searchKey = "%EC%82%B0%EA%B3%BC%20%EB%93%A4" //종로구
        }
        else if row == 9
        {
            searchKey = "%EB%86%8D%EA%B2%BD%EC%A7%80" //종로구
        }
        else if row == 10
        {
            searchKey = "%EC%97%BC%EC%A0%84" //종로구
        }
        else if row == 11
        {
            searchKey = "%ED%95%98%EC%B2%9C"
        }
        else if row == 12
        {
            searchKey = "%EC%95%94%EB%B0%98"
        }
        else if row == 13
        {
            searchKey = "%EC%A1%B0%ED%95%98%EB%8C%80"
        }
        else if row == 14
        {
            searchKey = "%EB%91%91"
        }
        else if row == 15
        {
            searchKey = "%EC%8A%B5%EC%A7%80"
        }
        else if row == 16
        {
            searchKey = "%EC%97%B0%EC%95%88"
        }
        else
        {
            searchKey = "%EC%88%B2"
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        authorizeSR()
        
        self.pickerView.delegate = self;
        self.pickerView.dataSource = self;
    }

    override func prepare(for segue: UIStoryboardSegue, sender:Any?) // 데이터 준비하는 프리페어 (내가함)
    { // 대상이 되는 메소드에서는 언와인드 메소드가 동작 (아무 동작 안하더라도 있어야 함)
        if segue.identifier == "segueToTableView"
        {
            if let navController = segue.destination as? UINavigationController
            { // 테이블뷰 앞단에 내비게이션이 있다면 내비게이션 적어줘야함
                if let hospitalTableViewController = navController.topViewController as? HospitalTableViewController
                {
                    hospitalTableViewController.url = url
                    hospitalTableViewController.urlsearchKey = searchKey
                    hospitalTableViewController.url2 = url2
                }
            }
        }
    }
}

