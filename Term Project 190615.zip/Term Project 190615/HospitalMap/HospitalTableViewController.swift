//
//  HospitalTableViewController.swift
//  HospitalMap
//
//  Created by kpugame on 2019. 4. 22..
//  Copyright © 2019년 Sumin Yeom. All rights reserved.
//

import UIKit

class HospitalTableViewController: UITableViewController, XMLParserDelegate
{
    @IBOutlet var tbData: UITableView!
    
    var url : String?
    var urlsearchKey : String?
    var url2 : String?
    
    var parser = XMLParser()
    var posts = NSMutableArray()
    
    var elements = NSMutableDictionary()
    var element = NSString()
    
    var name = NSMutableString()
    var habit = NSMutableString()
    
    var XPos = NSMutableString()
    var YPos = NSMutableString()
    
    var creature = ""
    var creature_utf8 = ""
    
    func beginParsing()
    {
        posts = []
        parser = XMLParser(contentsOf:(URL(string:url!+urlsearchKey!+url2!))!)!
        parser.delegate = self
        parser.parse()
        tbData!.reloadData()
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        element = elementName as NSString
        
        if (elementName as NSString).isEqual("item")
        {
            elements = NSMutableDictionary()
            elements = [:]
            name = NSMutableString()
            name = ""
            habit = NSMutableString()
            habit = ""
            
            XPos = NSMutableString()
            XPos = ""
            YPos = NSMutableString()
            YPos = ""
        }
    }
    
    func parser(_ parser:XMLParser, foundCharacters string: String)
    {
        if element.isEqual(to: "sciKr")
        {
            name.append(string)
        }
        else if element.isEqual(to: "distrInh")
        {
           habit.append(string)
        }
            /*
        else if element.isEqual(to: "lonD")
        {
            XPos.append(string)
        }
        else if element.isEqual(to: "latD")
        {
            YPos.append(string)
        }*/
        
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if (elementName as NSString).isEqual(to: "item")
        {
            if (!name.isEqual(nil))
            {
                elements.setObject(name, forKey: "sciKr" as NSCopying)
            }
            
            if (!habit.isEqual(nil))            {
                elements.setObject(habit, forKey: "distrInh" as NSCopying)
            }
            
            /*
            if (!XPos.isEqual(nil))
            {
                elements.setObject(XPos, forKey: "lonD" as NSCopying)
            }
            
            if (!YPos.isEqual(nil))
            {
                elements.setObject(YPos, forKey: "latD" as NSCopying)
            }*/
             
            
            posts.add(elements)
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count
    }

    var colorNum : Int = 0
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        cell.textLabel?.text = (posts.object(at: indexPath.row) as AnyObject).value(forKey: "sciKr") as! NSString as String
        cell.detailTextLabel?.text = (posts.object(at: indexPath.row) as AnyObject).value(forKey: "distrInh") as! NSString as String
        if colorNum % 2 == 0 {
            cell.backgroundColor = UIColor.init(red: 0, green: 90, blue: 255, alpha: 0.1)
        }
        else {
            cell.backgroundColor = UIColor.white
        }
        colorNum += 1
        return cell
    }
    var audioController : AudioController!
    override func viewDidLoad()
    {
        audioController = AudioController()
        audioController.preloadAudioEffects(audioFilesNames: AudioEffectFiles)
        audioController.playerEffect(name: Blop)
        super.viewDidLoad()
        beginParsing()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.identifier == "segueToDetailMarine"
        {
            if let cell = sender as? UITableViewCell
            {
                let indexPath = tableView.indexPath(for: cell)
                creature = (posts.object(at: (indexPath?.row)!) as AnyObject).value(forKey: "sciKr") as! NSString as String
                
                creature_utf8 = creature.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
                
                if let detailMarineViewController = segue.destination as? DetailMarineViewController
                {
                    detailMarineViewController.url = "http://apis.data.go.kr/B551979/marineOrganismInhabitInfoService/getHabitatGisList?type=1&pageNo=1&numOfRows=300&_type=xml&searchKey=" + creature_utf8 + url2!
                    detailMarineViewController.mapurl = "http://apis.data.go.kr/B551979/marineOrganismInhabitInfoService/getHabitatGisList?type=1&pageNo=1&numOfRows=300&_type=xml&searchKey=" + creature_utf8 + url2!
                }
            }
        }
    }
}
